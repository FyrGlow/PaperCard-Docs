import { defineClientConfig } from "vuepress/client";
import { defineRevealJsConfig } from "vuepress-plugin-md-enhance/client";

defineRevealJsConfig({
  // 在此设置 reveal.js 选项
  mouseWheel: true,
});

export default defineClientConfig({
  // ...
});

export const useRevealJs = () => [
  import(/* webpackChunkName: "reveal" */ "D:/projects/new/my-docs/node_modules/reveal.js/dist/reveal.esm.js"),
  import(/* webpackChunkName: "reveal" */ "D:/projects/new/my-docs/node_modules/reveal.js/plugin/markdown/markdown.esm.js"),
  ];

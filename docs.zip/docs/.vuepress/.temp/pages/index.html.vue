<template><div><p>这是项目主页的案例。你可以在这里放置你的主体内容。</p>
<p>想要使用此布局，你需要在页面 front matter 中设置 <code v-pre>home: true</code>。</p>
<p>配置项的相关说明详见 <a href="https://theme-hope.vuejs.press/zh/guide/layout/home/" target="_blank" rel="noopener noreferrer">项目主页配置<ExternalLinkIcon/></a>。</p>
</div></template>


